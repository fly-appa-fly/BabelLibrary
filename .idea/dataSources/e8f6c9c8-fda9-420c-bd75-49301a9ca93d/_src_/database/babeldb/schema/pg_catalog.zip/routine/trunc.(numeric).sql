create function trunc(numeric) returns numeric
LANGUAGE SQL
AS $$
select pg_catalog.trunc($1,0)
$$;
